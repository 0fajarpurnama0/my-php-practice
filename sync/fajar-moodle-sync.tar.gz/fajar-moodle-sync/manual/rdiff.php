<?php
echo system("rdiff patch test_profile/backup.mbz.backup test_profile/backup.mbz.delta test_profile/backup.mbz;");
?>

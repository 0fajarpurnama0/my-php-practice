
    <?php 
    $directory = "/var/www/html/fajar_moodle";
    $moodle_url = "127.0.0.1/fajar_moodle";
    ?>
    